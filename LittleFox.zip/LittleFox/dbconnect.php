<?php

$con = mysqli_connect('localhost','root','','Gym');
if(!$con){
    die('Failed to connect to database'.mysqli_error());
}

?>