<header>
			<div class="top-header">
				<div class="zerogrid">
					<div class="row">
						<div class="col-1-3">
							<div class="wrap-col">
								<span><i class="fa fa-map-marker"></i> <strong>Bangalore</strong>Karnataka,India</span>
							</div>
						</div>
						<div class="col-1-3">
							<div class="wrap-col">
								<span><i class="fa fa-phone"></i> 123 456 7890</span>
							</div>
						</div>
						<div class="col-1-3">
							<div class="wrap-col">
								<span><i class="fa fa-clock-o"></i> Mon-Fri 5:00-20:00, Sat-Sun 07:00-05:00</span>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="logo">
				<a href="index.php">LittleFox</a>
				<span>The Best Fitness Grow Your Strength</span>
			</div>
			<div id="cssmenu" class="t-left">
				<ul>
				
				   <li class="active"><a href="index.php"><span>LittleFox</span></a></li>
				   
				   <!--<li><a href="index.php"><span>Archive</span></a></li>-->
				   <li><a href="about.php"><span>About us</span></a></li>
				   <li class="last"><a href="contact.php"><span>Contact</span></a></li>
				   <li><a href="register.php"><span>Sign in | Sign up</span></a></li>
				</ul>
			</div>
			<div id="owl-slide" class="owl-carousel">
				<div class="item">
					<img src="images/slide24.jpg" />
					<!-- Static Header -->
					<div class="header-text hidden-xs">
						<div class="col-md-12 text-left">
							<h1>LEARN BOXING</h1>
							<p>Best MMA Coaches In The Country</p>
							<a class="button" href="about.php">Read More</a>
						</div>
					</div><!-- /header-text -->
				</div>
				<div class="item">
					<img src="images/slide11.jpg" />
					<!-- Static Header -->
					<div class="header-text hidden-xs">
						<div class="col-md-12 text-left">
							<h1>LEARN EXECRISE</h1>
							<p>Best Exercise Coaches In The Country</p>
							<a class="button" href="single.html">Read More</a>
						</div>
					</div><!-- /header-text -->
				</div>
				<div class="item">
					<img src="images/slide41.jpg" />
					<!-- Static Header -->
					<div class="header-text hidden-xs">
						<div class="col-md-12 text-left">
							<h1>LEARN YOGA</h1>
							<p>Best YOGA Coaches In The Country</p>
							<a class="button" href="single.html">Read More</a>
						</div>
					</div><!-- /header-text -->
					
				</div>
			</div>
		</header>