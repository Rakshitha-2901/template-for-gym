


<footer>
			<div class="zerogrid wrap-footer">
				<div class="row">
					<div class="col-1-4 col-footer-1">
						<div class="wrap-col">
							<h3 class="widget-title">About Us</h3>
							<p>LittleFox Gym Fitness Institute was started on World Health Day on 8th oct 2001. It’s been more than a two decade of educating people in fitness. Every year 1000+ students pass out of the institute. Littlefox Gym Fitness Institute offers the most exciting and up-to-date curriculum as well as ongoing training in all aspects of the fitness industry. </p>
							<p></p>
						</div>
					</div>
					<div class="col-1-4 col-footer-2">
						<div class="wrap-col">
							<h3 class="widget-title">Recent Post</h3>
							<ul>
								<li><a href="https://dailyburn.com/life/fitness/best-fit-travel-countries/">MOST VISITED COUNTRIES</a></li>
								<li><a href="https://www.startupindia.gov.in/">5 PLACES THAT MAKE A GREAT HOLIDAY</a></li>
								<li><a href="https://dailyburn.com/life/fitness/best-fit-travel-countries/">Best Anime</a></li>
								<li><a href="https://www.startupindia.gov.in/">STARTUP INDIAN Companiess</a></li>
							</ul>
						</div>
					</div>
					<div class="col-1-4 col-footer-3">
						<div class="wrap-col">
							<!-- // We need to add something new-->
							<h3 class="widget-title">Contributer</h3>
							<a href="#">Somshekar17 </a><br>
							<a href="#">Shankar </a><br>
							<a href="#">Rakshitha </a><br>
							<a href="#">Vandana </a><br>
							<a href="#">Veronica </a>

													
							
							
						</div>
					</div>
					<div class="col-1-4 col-footer-4">
						<div class="wrap-col">
							<h3 class="widget-title">Where to Find Us</h3>
							<div class="row">
								<address>
									<strong>LittleFox</strong>
									<br>
									Bangalore
									<br>
									Karnataka
									<br>
									India
								</address>
								<p>
									<strong>Opening Hours:</strong>
									<br>
									Mon - Fri: 05:00 - 20:00
									<br>
									Sat - Sun: 07:00 - 05:00
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="copyright">
				<div class="zerogrid wrapper">
					Copyright @ LittleFox - Designed by Somshekar<a herf ="www.github.com/somshekar17"></a>
					<ul class="quick-link">
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Terms of Use</a></li>
					</ul>
				</div>
			</div>
		</footer>
		
		<!-- carousel -->
		<script src="owl-carousel/owl.carousel.js"></script>
		<script>
		$(document).ready(function() {
		  $("#owl-slide").owlCarousel({
			autoPlay: 3000,
			items : 1,
			itemsDesktop : [1199,1],
			itemsDesktopSmall : [979,1],
			itemsTablet : [768, 1],
			itemsMobile : [479, 1],
			navigation: true,
			navigationText: ['<i class="fa fa-chevron-left fa-5x"></i>', '<i class="fa fa-chevron-right fa-5x"></i>'],
			pagination: false
		  });
		});
		</script>
	</div>

 